<script setup>
    const user = useSupabaseUser();
</script>

<template>
    <NuxtLayout>
        <NuxtPage />
    </NuxtLayout>
</template>
