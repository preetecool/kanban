<template></template>

<script setup lang="ts">
    definePageMeta({
        layout: "dashboard",
    });
</script>
<style lang="scss" scoped></style>
