export const useDB = defineStore("db", {
	state: () => ({
		test: "test",
		selectedTask: [{}]
	}),
	actions: {
		registerUser() {
			return "";
		}
	}
});
